// ASHA Awaaz — offline queue.
//
// Rural 2G reality: the network drops mid-shift. A confirmed visit-note is
// never lost — it is queued in localStorage and she is TOLD it is queued.
// On reconnect the queue drains (P1: drains to a no-op "synced" marker, since
// there is no datastore yet; the Supabase push slots in here in Phase 2).
//
// This is NOT a datastore. It is a local durability buffer for the capture
// path — deliberately in P1 scope, unlike the deferred dashboard/Supabase.
"use client";

import { VisitNote } from "./schema";

const QUEUE_KEY = "asha-awaaz:queue:v1";

export interface QueuedNote {
  visitNote: VisitNote;
  queued_at: string;
  synced: boolean;
}

function read(): QueuedNote[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(QUEUE_KEY);
    return raw ? (JSON.parse(raw) as QueuedNote[]) : [];
  } catch {
    return [];
  }
}

function write(items: QueuedNote[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(QUEUE_KEY, JSON.stringify(items));
  } catch {
    // Storage full / disabled — swallow; the UI still shows the current note.
  }
}

export function enqueue(note: VisitNote): QueuedNote {
  const item: QueuedNote = {
    visitNote: note,
    queued_at: new Date().toISOString(),
    synced: false,
  };
  const items = read();
  items.push(item);
  write(items);
  return item;
}

export function pendingCount(): number {
  return read().filter((i) => !i.synced).length;
}

export function isOnline(): boolean {
  return typeof navigator === "undefined" ? true : navigator.onLine;
}

// Drain: in P1 there is no server, so this marks pending items synced.
// Phase 2 replaces the body with the Supabase insert, keeping the signature.
export async function drain(): Promise<number> {
  if (!isOnline()) return 0;
  const items = read();
  let drained = 0;
  for (const item of items) {
    if (!item.synced) {
      // TODO Phase 2: await pushToSupabase(item.visitNote)
      item.synced = true;
      drained++;
    }
  }
  write(items);
  return drained;
}
