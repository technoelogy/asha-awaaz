// ASHA Awaaz — voice capture.
//
// WISPR INTEGRATION POINT
// -----------------------
// Wispr Flow dictates into whatever input is focused. So the transcript
// textarea below IS the integration surface: tapping the mic focuses it and
// Wispr types the Hindi/Hinglish transcript straight in. No competing ASR is
// wired here (Wispr-only, per brief). When the Wispr web SDK is added, call
// its start()/stop() in handleMicTap / handleStop and stream partials into
// setTranscript — the rest of the flow is unchanged.
//
// Mock samples populate the textarea with canned transcripts and carry a
// mockSampleId so the structuring route returns the matching rich fixture.
"use client";

import { useRef, useState } from "react";
import { VisitLanguage } from "../lib/schema";
import { MOCK_SAMPLES } from "../lib/mockData";

interface Props {
  onStructure: (args: {
    transcript: string;
    language: VisitLanguage;
    mockSampleId?: string;
  }) => void;
  busy: boolean;
}

export default function MicCapture({ onStructure, busy }: Props) {
  const [transcript, setTranscript] = useState("");
  const [language, setLanguage] = useState<VisitLanguage>("hi-en");
  const [recording, setRecording] = useState(false);
  const [sampleId, setSampleId] = useState<string | undefined>(undefined);
  const taRef = useRef<HTMLTextAreaElement>(null);

  function handleMicTap() {
    // Wispr start() goes here. For now: focus the field so Wispr can dictate.
    setRecording((r) => !r);
    taRef.current?.focus();
  }

  function handleSample(id: string, text: string) {
    setTranscript(text);
    setSampleId(id);
    setRecording(false);
  }

  function handleEdit(v: string) {
    setTranscript(v);
    // Manual edits detach from the canned fixture -> structure as free text.
    setSampleId(undefined);
  }

  const canStructure = transcript.trim().length > 0 && !busy;

  return (
    <div className="aa-card">
      <h1 className="aa-h1">नई विज़िट दर्ज करें</h1>
      <p className="aa-sub">Log a visit — बस बोलिए, टाइप मत कीजिए।</p>

      <button
        type="button"
        className="aa-mic"
        data-recording={recording}
        onClick={handleMicTap}
        aria-pressed={recording}
      >
        <span className="aa-mic-ring" aria-hidden="true">
          {recording ? "■" : "🎙"}
        </span>
        <span className="aa-mic-label">
          {recording ? "सुन रहे हैं… रोकने के लिए टैप करें" : "बोलने के लिए टैप करें"}
        </span>
        <span className="aa-mic-hint">
          Wispr से हिंदी या हिंग्लिश में बोलिए
        </span>
      </button>

      <div className="aa-field-label">सुनी गई बात (Wispr transcript)</div>
      <textarea
        ref={taRef}
        className="aa-transcript"
        value={transcript}
        onChange={(e) => handleEdit(e.target.value)}
        placeholder="उदाहरण: सुनीता देवी, उम्र 24 साल, 28वां हफ़्ता, बी पी नॉर्मल, आयरन गोली ले रही है…"
        dir="auto"
      />

      <div className="aa-row" style={{ marginTop: 12 }}>
        <span className="aa-field-label" style={{ margin: 0 }}>भाषा</span>
        <div className="aa-seg" role="group" aria-label="language">
          <button
            type="button"
            aria-pressed={language === "hi"}
            onClick={() => setLanguage("hi")}
          >
            हिंदी
          </button>
          <button
            type="button"
            aria-pressed={language === "hi-en"}
            onClick={() => setLanguage("hi-en")}
          >
            Hinglish
          </button>
        </div>
      </div>

      <button
        type="button"
        className="aa-btn"
        disabled={!canStructure}
        onClick={() =>
          onStructure({ transcript: transcript.trim(), language, mockSampleId: sampleId })
        }
      >
        {busy ? "समझ रहे हैं…" : "समझें और जाँचें →"}
      </button>

      <div className="aa-samples">
        <div className="aa-samples-head">Demo samples (mock)</div>
        {MOCK_SAMPLES.map((s) => (
          <button
            key={s.id}
            type="button"
            className="aa-sample"
            onClick={() => handleSample(s.id, s.transcript)}
          >
            {s.label}
            <small>{s.transcript}</small>
          </button>
        ))}
      </div>
    </div>
  );
}
